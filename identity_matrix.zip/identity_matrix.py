""" For this task, you are required to use the trinket IDE below to create a program that prints the mirror image of an n-dimensional identity matrix(where n is input by the user).

An identity matrix is defined as a square matrix with 1's running from the top left of the square to the bottom right.
The rest are 0's. The identity matrix has applications ranging from machine learning to the general theory of relativity.
 """
""" Input: 2
Output: 1 0
0 1

Input:  4
Output: 1 0 0 0
0 1 0 0
0 0 1 0
0 0 0 1
 """
# Python code to print identity matrix

user_input = int(input('Please enter a number:'))

# Create a function to print identity matrix


def identity(size):
    for row in range(0, size):
        for col in range(0, size):

            # Here end is used to stay in same line
            if (row == col):  # the matrix is a cube so the number of rows and colums is the same
                print("1 ", end=" ")
            else:
                print("0 ", end=" ")
        print()


# Driver Code
size = user_input
identity(size)
